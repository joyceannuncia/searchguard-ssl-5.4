export DEBIAN_FRONTEND=noninteractive
export ES_VERSION=2.3.5
export SG_VERSION=2.3.5.5
export SG_SSL_VERSION=2.3.5.15
export NETTY_NATIVE_VERSION=1.1.33.Fork17
export NETTY_NATIVE_CLASSIFIER=linux-x86_64

export ES_CONF_DIR=/etc/elasticsearch
export ES_BIN_DIR=/usr/share/elasticsearch/bin
export ES_PLUGIN_DIR=/usr/share/elasticsearch/plugins
